package griersoft.frogbot.ribbit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RibbitApplication {

	public static void main(String[] args) {
		SpringApplication.run(RibbitApplication.class, args);
	}

}
