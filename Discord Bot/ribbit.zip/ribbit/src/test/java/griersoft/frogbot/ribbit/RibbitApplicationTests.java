package griersoft.frogbot.ribbit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RibbitApplicationTests {

	@Test
	void contextLoads() {
	}

}
